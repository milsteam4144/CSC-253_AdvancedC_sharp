﻿/**
* 10/4/2018
* CSC 253
* Mallory Milstead
* Method that accepts a string from a user and returns the number of words in the string
*/



using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3HW1_Milstead
{
    class Program

        
    {
        static void Main(string[] args)
        {

            string runAgain;
           

            do
            {

                //Display directions to the user
                Console.WriteLine("Enter a string to determine the number of words in the string: \n");

                //Get input from the user
                string userInput = Console.ReadLine();

                //Assign the returned counter int (from the method) to the variable numOfWords
                int numOfWords = getNumOfWords(userInput);

                //Display the number of words to the user
                Console.WriteLine("\nThere are " + numOfWords + " words in the string\n");

                //Ask the user to run again
                Console.WriteLine("Would you like to run the program again? y/n \n");
                runAgain = Console.ReadLine().ToLower();
            }

            while (runAgain == "y");

        }

        static int getNumOfWords(string userInput)
          
        {
            //Create an array of tokens from the userInput using the .Split method
            string[] tokens = userInput.Split(null);

            //Count the number of items in the tokens array
            int counter = tokens.Count();

            return counter;

        }
    }
}
