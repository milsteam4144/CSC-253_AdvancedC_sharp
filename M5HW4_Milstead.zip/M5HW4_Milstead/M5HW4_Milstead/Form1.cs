﻿/**
* 11/14/2018
* CSC 253
* Mallory Milstead
* Use DataGridView to display data that has been sorted and numerical representations of data (min, max..etc) using methods consisting of SQL statments
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M5HW4_Milstead
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDBDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);

        }

        private void sortPopAsc_Click(object sender, EventArgs e)
        {
            //Call the method to sort the table by ascending population
            this.cityTableAdapter.FillByPopAsc(this.populationDBDataSet.City);
        }

        private void sortPopDesc_Click(object sender, EventArgs e)
        {
            //Call the method to sort the table by descending population
            this.cityTableAdapter.FillByPopDesc(this.populationDBDataSet.City);
        }

        private void sortCityName_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.FillByCityName(this.populationDBDataSet.City);
        }

        private void getTotalPop_Click(object sender, EventArgs e)
        {
            //Call the method to get the total population for all cities, assign it to a variable
            int totalPop = (int) this.cityTableAdapter.GetTotalPop();

            //Display the variable in a Label
            totalPopLabel.Text = totalPop.ToString("N0");
        }

        private void getAvgPop_Click(object sender, EventArgs e)
        {
            //Call the method to get the average population for all cities, assign it to a variable
            double avgPop = (double)this.cityTableAdapter.GetAvgPop();

            //Display the variable in a Label
            avgPopLabel.Text = avgPop.ToString("N0");
        }

        private void highPopButton_Click(object sender, EventArgs e)
        {
            //Call the method to get the highest population for all cities, assign it to a variable
            double highPop = (double)this.cityTableAdapter.getMaxPop();

            //Display the variable in a Label
            highLabel.Text = highPop.ToString("N0");
        }

        private void lowPopButton_Click(object sender, EventArgs e)
        {
            //Call the method to get the lowest population for all cities, assign it to a variable
            double lowPop = (double)this.cityTableAdapter.getMinPop();

            //Display the variable in a Label
            lowLabel.Text = lowPop.ToString("N0");
        }

        private void resetViewButton_Click(object sender, EventArgs e)
        {
            //Call the built-in Fill method to repopulate the DataGridView with the default records (unsorted)
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);

            //Reset the labels
            totalPopLabel.Text = "";
            avgPopLabel.Text = "";
            highLabel.Text = "";
            lowLabel.Text = "";
        }
    }
}
