﻿namespace M1HW2_Milstead
{
    partial class penniesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dayNum_textbox = new System.Windows.Forms.TextBox();
            this.output_Label = new System.Windows.Forms.Label();
            this.calc_pay_Button = new System.Windows.Forms.Button();
            this.close_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(461, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Calculate the pay if a penny is paid the first day and doubled everyday.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(39, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(205, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Enter the number of days worked:";
            // 
            // dayNum_textbox
            // 
            this.dayNum_textbox.Location = new System.Drawing.Point(250, 54);
            this.dayNum_textbox.Name = "dayNum_textbox";
            this.dayNum_textbox.Size = new System.Drawing.Size(100, 20);
            this.dayNum_textbox.TabIndex = 2;
            // 
            // output_Label
            // 
            this.output_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.output_Label.Location = new System.Drawing.Point(28, 87);
            this.output_Label.Name = "output_Label";
            this.output_Label.Size = new System.Drawing.Size(415, 36);
            this.output_Label.TabIndex = 3;
            this.output_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // calc_pay_Button
            // 
            this.calc_pay_Button.Location = new System.Drawing.Point(97, 137);
            this.calc_pay_Button.Name = "calc_pay_Button";
            this.calc_pay_Button.Size = new System.Drawing.Size(106, 23);
            this.calc_pay_Button.TabIndex = 4;
            this.calc_pay_Button.Text = "Calculate Pay";
            this.calc_pay_Button.UseVisualStyleBackColor = true;
            this.calc_pay_Button.Click += new System.EventHandler(this.calc_pay_Button_Click);
            // 
            // close_button
            // 
            this.close_button.Location = new System.Drawing.Point(250, 137);
            this.close_button.Name = "close_button";
            this.close_button.Size = new System.Drawing.Size(100, 23);
            this.close_button.TabIndex = 5;
            this.close_button.Text = "Close";
            this.close_button.UseVisualStyleBackColor = true;
            this.close_button.Click += new System.EventHandler(this.close_button_Click);
            // 
            // penniesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 182);
            this.Controls.Add(this.close_button);
            this.Controls.Add(this.calc_pay_Button);
            this.Controls.Add(this.output_Label);
            this.Controls.Add(this.dayNum_textbox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "penniesForm";
            this.Text = "Calculate Pennies for Pay";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox dayNum_textbox;
        private System.Windows.Forms.Label output_Label;
        private System.Windows.Forms.Button calc_pay_Button;
        private System.Windows.Forms.Button close_button;
    }
}

