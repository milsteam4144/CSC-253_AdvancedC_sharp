﻿/**
* 9/2/2018
* CSC 253
* Mallory Milstead
* This program calculates an individual's pay if they start off at a penny and pay doubles each day.
*/


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW2_Milstead
{
    public partial class penniesForm : Form
    {
        public penniesForm()
        {
            InitializeComponent();
        }

        private void calc_pay_Button_Click(object sender, EventArgs e)
        {
            int dayNum; //To hold the number of days worked
            decimal totalPay = 0; //To hold the amount of money paid
            int payRate = 1; //To hold the rate of pay for each day

            //If user input can be parsed into an integet
            if (int.TryParse(dayNum_textbox.Text, out dayNum))
            {
                for (int count = 0; count<dayNum; count++)
                {
                    
                    totalPay += payRate;
                    payRate *= 2;
                }
                totalPay = totalPay / 100; //To convert the amount to cents
                output_Label.Text = ("The total pay for " + dayNum + " days" + " is " + totalPay.ToString("C")); //Display results
            }
            else
            {
                //Prompt user to enter valid integer if not done
                MessageBox.Show("Enter a valid integer.");
                dayNum_textbox.Text = ""; //Clears the input textbox of invalid input
            }
        }

        private void close_button_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
