﻿/**
* 10/19/2018
* CSC 253
* Mallory Milstead
* Inputs a sentence and converts it to morse code based on dictionary values read from a text file
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace M3HW4_Milstead
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)//keeps the program running
            {
                Console.WriteLine("Enter a sentence to convert it to morse code.\nIf there is not a code for a character, it will remain unchanged.");
                string sentence_to_convert = Console.ReadLine().ToUpper();//Convert sentence to uppercase letters
                Console.WriteLine("The sentence in morse code: " + (convert_to_morse(sentence_to_convert)) + "\n"); //Call the method to encode sentence and display results
            }

        }

        public static string convert_to_morse(string sentence)
        {
            //Create a dictionary to hold the data. Key = letter/num/punctuation Value = morse code
            Dictionary<char, string> MorseCode = new Dictionary<char, string>();
            MorseCode.Add(' ', " "); //Give the dictionary a key, value pair for a blank char
            //Empty string to hold the sentence once converted to morse code
            string converted_sentence = "";

            try
           {
                using (StreamReader reader = File.OpenText("morseCode.txt"))
                {
                    while (!reader.EndOfStream)
                    {
                        char original = reader.ReadLine()[0];//Assign the first character of the line to a char variable
                        string encoded = reader.ReadLine();//Assign the next line to a string variable

                        MorseCode.Add(original, encoded);//Add the key, value pair to the dictionary
                    }
                }

                foreach(char letter in sentence)
                {
                    if (MorseCode.TryGetValue(letter, out string key)) //if the key is present in the dictionary, output the value
                    {
                        converted_sentence += key; //Add value to the encoded sentence
                    }
                    else
                    {
                        converted_sentence += letter;//if the key is not in the dictionary, keep the char the same and add it to sentence
                    }
                }

                return converted_sentence;
            }

            catch
            {
               Console.WriteLine("A necessary file could not be found.");
               return null;
            }
        }
    }
}
