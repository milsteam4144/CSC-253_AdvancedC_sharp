﻿/**
* 11/14/2018
* CSC 253
* Mallory Milstead
* Prompts user to enter a name to search the database for. Passes that name to a method that searches and returns/displays the records that pertially or fully match the name.
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M5HW3_Milstead
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personnelDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);

        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            //Calls the method to search the table. The first argument is which table in which database to use, the second reflects the @value in the method (what to search for
            this.employeeTableAdapter.SearchName(this.personnelDataSet.Employee, searchTB.Text);
        }

        private void showAllButton_Click(object sender, EventArgs e)
        {
            //Calls the Fill method which includes all records in the table
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);
        }
    }
}
