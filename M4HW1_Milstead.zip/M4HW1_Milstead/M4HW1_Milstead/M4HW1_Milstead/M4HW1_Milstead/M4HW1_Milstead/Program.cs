﻿//Mallory Milstead
//CSC 253
//11/1/2018
//Creates a subclass(ProductionWorker) of baseclass(Employee), gets and validates user input as ProductionWorker object properties and displays properties


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeClass_Library;

namespace M4HW1_Milstead
{
    class Program
    {
        

        static void Main(string[] args)
        {
           

            Console.WriteLine("Enter the first name of the worker: ");
            string firstName = Console.ReadLine();

            Console.WriteLine("Enter the last name of the worker: ");
            string lastName = Console.ReadLine();

            Console.WriteLine("Enter the employee number of the worker: ");
            int empNum;
            bool empNumInputGood; //Hold a boolean to determine if the input is valid. Will need this for each input validation
            do
            {
                string empNuminput = Console.ReadLine();//Get the input
                empNumInputGood = InputValidation.empNumGood(empNuminput); //Call the method to determine if the input is an integer. If it is, this loop will not run again
                int.TryParse(empNuminput, out empNum);//if the input can be parsed, assign it to the empNum variable             
            }
            while (empNumInputGood == false);
            

            Console.WriteLine("Enter the shift number of the worker: "); //Must be 1,2, or 3
            int shiftNum;
            bool shiftNumInputGood;
            do
            {
                string shiftNumInput = Console.ReadLine();
                shiftNumInputGood = InputValidation.shiftNumGood(shiftNumInput);
                int.TryParse(shiftNumInput, out shiftNum);
            }
            while (shiftNumInputGood == false);
            

            

            Console.WriteLine("Enter the pay rate of the worker: ");
            decimal payRate;
            bool payRateInputGood;
            do
            {
                string payRateInput = Console.ReadLine();
                payRateInputGood = InputValidation.payRateNumGood(payRateInput);
                decimal.TryParse(payRateInput, out payRate);

            }
            while (payRateInputGood == false);

            ProductionWorker worker = new ProductionWorker(firstName, lastName, empNum, shiftNum, payRate); //Create object

            //Display Information
            Console.WriteLine("\nProdcution Worker Information:\n");
            Console.WriteLine($"Name: {worker._firstName +" " + worker._lastName}");
            Console.WriteLine($"Employee Number: {worker._empNumber.ToString()}");
            Console.WriteLine($"Shift: {worker._shift.ToString()}");
            Console.WriteLine($"Pay Rate: ${worker._payRate.ToString()}");
            Console.ReadLine();
        }
    }
}
