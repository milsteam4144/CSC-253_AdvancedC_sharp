﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClass_Library
{
    public class InputValidation
    {
        public static bool empNumGood(string userInput)
        {
            int empNum;
            bool inputGood = false;
            if (int.TryParse(userInput, out empNum))
            {
                inputGood = true;
            }
            else
            {
                Console.WriteLine("Invalid Employee Number\nEnter a valid employee number: ");
            }
            return inputGood;

        }

        public static bool shiftNumGood(string userInput)
        {
            int shiftNum;
            bool inputGood = false;
            if (int.TryParse(userInput, out shiftNum))
            {
                if (shiftNum == 1 || shiftNum == 2 || shiftNum == 3)
                {
                    inputGood = true;
                }
                else
                {
                    Console.WriteLine("Invalid Shift Number\nEnter a 1, 2 or 3: ");
                }
            }
            else
            {
                Console.WriteLine("Invalid Shift Number\nEnter a 1, 2 or 3: ");
            }


            return inputGood;
        }

        public static bool payRateNumGood(string userInput)
        {
            decimal payRate;
            bool inputGood = false;
            if (decimal.TryParse(userInput, out payRate))
            {
                inputGood = true;
            }
            else
            {
                Console.WriteLine("Invalid Pay Rate\nEnter a valid pay rate: $");
            }
            return inputGood;
        }
    }
}
