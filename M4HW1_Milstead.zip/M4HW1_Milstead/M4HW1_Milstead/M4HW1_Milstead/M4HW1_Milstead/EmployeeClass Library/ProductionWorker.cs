﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M4HW1_Milstead
{
    public class ProductionWorker : Employee
    {
        //Field
        public int _shift { get; set; }
        public decimal _payRate { get; set; }

        //Constructor
        public ProductionWorker(string FirstName, string LastName, int EmpNumber, int Shift, decimal PayRate) : base(FirstName, LastName, EmpNumber)
        {
            _shift = Shift;
            _payRate = PayRate;

        }

    }

    
}
