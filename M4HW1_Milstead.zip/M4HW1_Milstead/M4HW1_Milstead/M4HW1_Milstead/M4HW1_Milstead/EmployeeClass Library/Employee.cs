﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M4HW1_Milstead
{
    public class Employee
    {
        //Fields
        public string _firstName { get; set; }
        public string _lastName { get; set; }
        public int _empNumber { get; set; }

        //Constructor
        public Employee(string FirstName, string LastName, int EmpNumber)
        {
            _firstName = FirstName;
            _lastName = LastName;
            _empNumber = EmpNumber;
        }

        
    }
}
