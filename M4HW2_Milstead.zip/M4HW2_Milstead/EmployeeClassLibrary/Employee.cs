﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    public class Employee
    {

        //Backing Fields
        private string _firstName { get; set; }
        private string _lastName { get; set; }
        private int _empNumber { get; set; }

        //Constructor
        public Employee()
        {

        }

        //FirstName Property
        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }

        //LastName Property
        public string LasttName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }

        //EmpNumber Property
        public int EmpNumber
        {
            get { return _empNumber; }
            set { _empNumber = value; }
        }
    }
}
