﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeClassLibrary
{
    public class ShiftSupervisor : Employee
    {
        //Fields
        public decimal _annualSalary { get; set; }
        public decimal _annualBonus { get; set; }

        //Constructor
        public ShiftSupervisor()
        {

        }

        //AnnualSalary Property
        public decimal AnnualSalary
        {
            get { return _annualSalary; }
            set { _annualSalary = value; }
        }

        //AnnualSalary Property
        public decimal AnnualBonus
        {
            get { return _annualBonus; }
            set { _annualBonus = value; }
        }
    }
}
