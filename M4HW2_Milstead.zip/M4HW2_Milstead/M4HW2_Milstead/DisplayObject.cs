﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M4HW2_Milstead
{
    public partial class DisplayObject : Form
    {
        public DisplayObject()
        {
            InitializeComponent();
        }
        
        //All code for this form is called and displayed in CreateObject.cs (Form)

        private void closeButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
