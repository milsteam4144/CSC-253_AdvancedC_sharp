﻿/**
* 11/2/2018
* CSC 253
* Mallory Milstead
* Creates a ShiftSupervisor class derived from Employee class, accepts user input as properties and creates and displays the object.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeClassLibrary; //To get this, click on the project you are in, Add--Reference--choose class library you want to use, then type it here.

namespace M4HW2_Milstead
{
    public partial class CreateObject : Form
    {
        public CreateObject()
        {
            InitializeComponent();
        }

        //Method to get properties from textboxes
        private void GetSupervisorData(ShiftSupervisor supervisor)
        {
            //Create temporary variables to be able to validate input for empNum, salary and bonus
            int empNum;
            decimal salary;
            decimal bonus;

            //Get the data from the textboxes and assign it to a supervisor object's properties
            if (firstNameTB.Text != "")
            {
                supervisor.FirstName = firstNameTB.Text;
            }
            else
            {
                MessageBox.Show("Must enter a first name.");
            }

            if (lastNameTB.Text != "")
            {
                supervisor.LasttName = lastNameTB.Text;
            }
            else
            {
                MessageBox.Show("Must enter a last name.");
            }
            

            //Validate the input for the non-string properties
            if (int.TryParse(empNumTB.Text, out empNum))
            {
                supervisor.EmpNumber = empNum;
            }
            else
            {
                MessageBox.Show("Invalid Employee Number");

            }

            if (decimal.TryParse(salaryTB.Text, out salary))
            {
                supervisor.AnnualSalary = salary;
            }
            else
            {
                MessageBox.Show("Invalid Salary");

            }

            if (decimal.TryParse(bonusTB.Text, out bonus))
            {
                supervisor.AnnualBonus = bonus;
            }
            else
            {
                MessageBox.Show("Invalid Bonus");

            }

        }      
            
            
        

        private void createButton_Click(object sender, EventArgs e)
        {
            //Create a ShiftSupervisor Object
            ShiftSupervisor supervisor = new ShiftSupervisor();

            //Call the method to assign properties to the object and pass it the newly created object
            GetSupervisorData(supervisor);

            //Display second form showing the object's properties
            DisplayObject display_form = new DisplayObject();

            //Assign the properties to the labels of the new form -- Must make these labels' modifiers properties public (go to their properties on their home form)
            display_form.firstNameLabel.Text = supervisor.FirstName;
            display_form.lastNameLabel.Text = supervisor.LasttName;
            display_form.empNumLabel.Text = supervisor.EmpNumber.ToString();
            display_form.salaryLabel.Text = supervisor.AnnualSalary.ToString("c");
            display_form.bonusLabel.Text = supervisor.AnnualBonus.ToString("c");

            //Display the new form (display_form) as long as the following properties are not ==0
            if (supervisor.EmpNumber != 0 && supervisor.AnnualSalary!=0 && supervisor.AnnualBonus != 0)
            {
                display_form.ShowDialog();
            }
            else
            {
                MessageBox.Show("Invalid Data entered on Create Object Form, please try again.");
            }
            
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
