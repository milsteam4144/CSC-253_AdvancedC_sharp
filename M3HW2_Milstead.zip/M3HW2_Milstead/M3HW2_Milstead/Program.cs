﻿/**
* 10/4/2018
* CSC 253
* Mallory Milstead
* Accepts a string of numbers separated by commas and returns the sum of the numbers
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3HW2_Milstead
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declare a string variable to control the loop
            string runAgain = "";
            

            do //This do-while loop continues until the user presses enter
            {
                //Declare a ConsoleKeyInfo object
                ConsoleKeyInfo key;
                //Declare an empty string to hold the input
                string nums = "";
                Console.WriteLine("Enter a list of numbers separated by commas to get their sum: ");
                do
                {
                    //Assign the keys the user presses into the ConsoleKeyInfo object
                    key = Console.ReadKey(true);

                    //If the key is a number or comma...
                    if ((key.Key >= ConsoleKey.D0 && key.Key <= ConsoleKey.D9) || key.Key == ConsoleKey.OemComma) 
                    {
                        //Add it to the list
                        nums += key.KeyChar;

                        //Show the key on the console
                        Console.Write(key.KeyChar);
                    }

                    //If the key is a backspace...
                    else if (key.Key == ConsoleKey.Backspace)
                    {
                        //Remove the last item from the list
                        nums = nums.Remove(nums.Count() -1);
                        Console.Write("\b \b");
                    }
                }

                
                while (key.Key != ConsoleKey.Enter); //Part of do while loop
                
                    //If the user presses enter, the above do-while loop breaks and this code is ran
                    nums = nums.TrimEnd(','); //Trim any tailing commas
                    int sum = getSum(nums); //Call the get sum method to add the ints
                    Console.WriteLine("\nThe sum of the numbers is " + sum); //Display the sum
                
                

                //Ask the user to run again
                Console.WriteLine("Would you like to run the program again? y/n \n");
                runAgain = Console.ReadLine().ToLower();

            }
            while (runAgain == "y");

        }

        static int getSum(string userInput)
        {
                //Initialize & Declare variable to hold sum
                int sum = 0;
                
                //Split the string of numbers and put them in an array
                string[] numbers = userInput.Split(',');

                foreach (string num in numbers)
                {
                    //Parse each string to an int
                    int int_num = int.Parse(num);
                    //Add each int to the sum
                    sum += int_num;
                }

                return sum;
            }
        }
    }

