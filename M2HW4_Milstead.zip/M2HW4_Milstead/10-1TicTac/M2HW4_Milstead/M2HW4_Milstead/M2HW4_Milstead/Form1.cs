﻿/**
* 10/1/2018
* CSC 253
* Mallory Milstead
* Iterates through a 2D array assigning random values of 0 or 1 to simulate the winner of a tic tac toe game
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW4_Milstead
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void newGameButton_Click(object sender, EventArgs e)
        {
            //Clear the outputLabel
            outputLabel.Text = "";

            //Create an array of label items
            Label[] labelArray = new Label[9];
            labelArray[0] = this.label1;
            labelArray[1] = this.label2;
            labelArray[2] = this.label3;
            labelArray[3] = this.label4;
            labelArray[4] = this.label5;
            labelArray[5] = this.label6;
            labelArray[6] = this.label7;
            labelArray[7] = this.label8;
            labelArray[8] = this.label9;

            //Create a random number object
            Random random = new Random();
            

            const int ROWS = 3;
            const int COLS = 3;

            int[,] gameBoard = new int[ROWS, COLS];//Create a 2D array to simualate the game board

            for (int row = 0; row <ROWS; row++)
            {
                for (int col = 0; col<COLS; col++)
                {
                    //for each item in the 2D array, assign it a random value of 0 or 1
                    gameBoard[row, col] = random.Next(0, 2);
                }
            }

            //Assign the gameBoard array items to the labels
            label1.Text = gameBoard[0, 0].ToString(); label2.Text = gameBoard[0, 1].ToString(); label3.Text = gameBoard[0, 2].ToString();
            label4.Text = gameBoard[1, 0].ToString(); label5.Text = gameBoard[1, 1].ToString(); label6.Text = gameBoard[1, 2].ToString();
            label7.Text = gameBoard[2, 0].ToString(); label8.Text = gameBoard[2, 1].ToString(); label9.Text = gameBoard[2, 2].ToString();

            //Check rows for matches
            if (gameBoard[0,0] + gameBoard[0,1] + gameBoard[0, 2] == 3) //top row 
            {
                outputLabel.Text = "X won!";
            }
            if (gameBoard[0, 0] + gameBoard[0, 1] + gameBoard[0, 2] == 0) //top row 
            {
                outputLabel.Text = "O won!";
            }
            if (gameBoard[1, 0] + gameBoard[1, 1]+ gameBoard[1, 2] == 3) //middle row 
            {
                outputLabel.Text =  "X won!";
            }
            if (gameBoard[1, 0] + gameBoard[1, 1] + gameBoard[1, 2] == 0) //middle row 
            {
                outputLabel.Text = "O won!";
            }
            if (gameBoard[2, 0] + gameBoard[2, 1] + gameBoard[2, 2] ==3) //bottom row 
            {
                outputLabel.Text =  "X won!";
            }
            if (gameBoard[2, 0] + gameBoard[2, 1] + gameBoard[2, 2] == 0) //bottom row 
            {
                outputLabel.Text = "O won!";
            }


            //Check columns for matches
            if (gameBoard[0, 0] + gameBoard[1, 0] + gameBoard[2, 0] == 3) //left column
            {
                outputLabel.Text = " X won!";
            }
            if (gameBoard[0, 0] + gameBoard[1, 0] + gameBoard[2, 0] == 0) //left column
            {
                    outputLabel.Text = " O won!";
            }
            if (gameBoard[0, 1] + gameBoard[1, 1] + gameBoard[2, 1] == 3) //middle column
            {
                outputLabel.Text = "X won!";
            }
            if (gameBoard[0, 1] + gameBoard[1, 1] + gameBoard[2, 1] == 0) //middle column
            {
                outputLabel.Text = "O won!";
            }
            if (gameBoard[0, 2] + gameBoard[1, 2] + gameBoard[2, 2] == 3) //right column
            {
                outputLabel.Text =  "X won!";
            }
            if (gameBoard[0, 2] + gameBoard[1, 2] + gameBoard[2, 2] == 0) //right column
            {
                outputLabel.Text = "O won!";
            }

            //Check for diagonal matches
            if (gameBoard[0, 0] + gameBoard[1, 1] + gameBoard[2, 2] == 3) 
            {
                outputLabel.Text = "X won!";
            }
            if (gameBoard[0, 0] + gameBoard[1, 1] + gameBoard[2, 2] == 0)
            {
                outputLabel.Text = "O won!";
            }
            if (gameBoard[0, 2] + gameBoard[1, 1] + gameBoard[2, 0] == 3)
            {
                outputLabel.Text =  "X won!";
            }
            if (gameBoard[0, 2] + gameBoard[1, 1] + gameBoard[2, 0] == 0)
            {
                outputLabel.Text = "O won!";
            }
            if (outputLabel.Text == "") //If none of the above conditions are true, display "Draw!"
            {
                outputLabel.Text = "Draw!";
            }
           
            

            //For each label in the labelArray, assign text of O or X
            foreach (Label i in labelArray)
            {
                if (i.Text == "0")
                {
                    i.Text = "O";
                }
                else
                {
                    i.Text = "X";
                }
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
