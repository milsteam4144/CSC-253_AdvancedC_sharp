﻿/**
* 9/26/2018
* CSC 253
* Mallory Milstead
* Read text from two files into two lists. Check if lists contain data entered by user. Give output to user.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace M2HW3_Milstead
{
    class Program
    {
        static void Main(string[] args)
        {


            try
            {
                //Create a list for the girl names
                List<string> girlNames = new List<string>();

                //Use the function to assign values to the list
                girlNames = getNames("GirlNames.txt");

                //Create a list for the boy names
                List<string> boyNames = new List<string>();

                //Use the function to assign values to the list
                boyNames = getNames("BoyNames.txt");

                //Get user input
                Console.WriteLine("Enter a name to determine if it was one of the most popular from 2000 to 2009: \nOr type exit to leave program.");
                string userInput = Console.ReadLine();
                Console.WriteLine();

                //While the user does not input exit, execute code below. If user inputs exit, program closes.
                while (userInput != "exit")
                {


                    //To capitalize the first letter of the name, get the first character and capitalize it. Then add the rest of the string back on except for the first letter
                    userInput = userInput.First().ToString().ToUpper() + userInput.Substring(1); ;



                    //If the name is in the girlNames list. Console text will be green
                    if ((containsName(userInput, girlNames)) == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(userInput + " was a popular girl's name");
                        Console.ResetColor();
                    }
                    //If the name is in the boyNames list. Console text will be green
                    if ((containsName(userInput, boyNames)) == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(userInput + " was a popular boy's name");
                        Console.ResetColor();
                    }
                    //If the name is not in either the girlNames list or boyNames list. Console text will be red
                    if ((containsName(userInput, boyNames)) == false && (containsName(userInput, girlNames)) == false)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(userInput + " was not a popular name for boys or girls");
                        Console.ResetColor();
                    }

                    //Get user input
                    Console.WriteLine("\n\nEnter a name to determine if it was one of the most popular from 2000 to 2009: \nOr type exit to leave program.");
                    userInput = Console.ReadLine();
                    Console.WriteLine();
                }

              }

            catch
            {
                //Display an error to user
                Console.WriteLine("One or more files cannot be found");
            }

            
        }

        //Function to get the names from a file and write them to a list
        private static List<string> getNames(string filename)
        {

            //Create an empty list to hold the names
            List<string> nameList = new List<string>();


            //Open the file
            StreamReader inputFile = File.OpenText(filename);

            //Read the names into a list
            while (!inputFile.EndOfStream)
            {
                nameList.Add(inputFile.ReadLine());
            }

            //Return the list of names
            return nameList;

        }
        //Function to check if the list contains a name. Returns a boolean value
        private static bool containsName(string name, List<string> nameList)
        {
            //Create a variable to hold the boolean
            bool contains = false;

            //If the name is in the list
            if (nameList.Contains(name))
            {
                //Assign true to boolean variable
                contains = true;
            }
            //Return boolean
            return contains;
        }
    }
}
