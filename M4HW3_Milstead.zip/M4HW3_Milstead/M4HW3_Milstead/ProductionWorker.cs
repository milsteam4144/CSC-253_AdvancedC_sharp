﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M4HW3_Milstead
{
    public class ProductionWorker
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int EmpNumber { get; set; }
        public int Shift { get; set; }
        public decimal PayRate { get; set; }

        //Constructor
        public ProductionWorker()
        {
        }
    }
}
