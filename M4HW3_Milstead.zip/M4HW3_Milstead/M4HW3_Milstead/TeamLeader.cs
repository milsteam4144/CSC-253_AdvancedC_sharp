﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M4HW3_Milstead
{
    public class TeamLeader : ProductionWorker
    {
        public decimal MonthlyBonus { get; set; }
        public int ReqTrainHrs { get; set; }
        public int MetTrainHrs { get; set; }

        //Constructor
        public TeamLeader()
        {
        }
    }
}
