﻿/**
* 11/7/2018
* CSC 253
* Mallory Milstead
* Creates a subclass of ProductionWorker (TeamLeader) and creates an object of this class with user-given peoperties
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M4HW3_Milstead
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Method to get properties from textboxes
        private void GetTeamLeaderData(TeamLeader teamLeader)
        {
            //Create temporary variables to be able to validate input for empNum, salary and bonus
            string firstName;
            string lastName;
            int empNum;
            decimal payRate;
            decimal bonus;
            int reqHrs;
            int metHrs;
            int shift;


            //Get the data from the textboxes and assign it to a supervisor object's properties
            firstName = firstNameTB.Text;
            if (firstName.Length != 0)
            {
                teamLeader.FirstName = firstNameTB.Text;
            }
            else
            {
                MessageBox.Show("Must enter a first name.");
            }

            lastName = lastNameTB.Text;
            if (lastName.Length != 0)
            {
                teamLeader.LastName = lastNameTB.Text;
            }
            else
            {
                MessageBox.Show("Must enter a last name.");
            }

            //Validate the input for the non-string properties
            if (decimal.TryParse(payRateTB.Text, out payRate))
            {
                teamLeader.PayRate = payRate;
            }
            else
            {
                MessageBox.Show("Invalid Pay Rate");

            }

                if (int.TryParse(shiftNumTB.Text, out shift))
                {
                    if (shift == 1 || shift == 2 || shift == 3)
                    {
                        teamLeader.Shift = shift;
                    }
                    else
                    {
                        MessageBox.Show("Invalid Shift");

                    }
                }
                else
                {
                    MessageBox.Show("Invalid Shift");

                }

                if (int.TryParse(empNumTB.Text, out empNum))
                {
                    teamLeader.EmpNumber = empNum;
                }
                else
                {
                    MessageBox.Show("Invalid Employee Number");

                }

                if (decimal.TryParse(monthlyBonusTB.Text, out bonus))
                {
                    teamLeader.MonthlyBonus = bonus;
                }
                else
                {
                    MessageBox.Show("Invalid Bonus");

                }

                if (int.TryParse(reqTrainHrsTB.Text, out reqHrs))
                {
                    teamLeader.ReqTrainHrs = reqHrs;
                }
                else
                {
                    MessageBox.Show("Invalid Required Training Hours");

                }

                if (int.TryParse(metTrainHrsTB.Text, out metHrs))
                {
                    teamLeader.MetTrainHrs = metHrs;
                }
                else
                {
                    MessageBox.Show("Invalid Attended Training Hours");

                }

            }

            private void button1_Click(object sender, EventArgs e)
            {
                //Create TeamLeader object
                TeamLeader teamleader = new TeamLeader();

                //Call the method to define the object's properties
                GetTeamLeaderData(teamleader);

                //Display the objet's properties in a MessageBox
                if (teamleader.FirstName != null && teamleader.LastName != null && teamleader.EmpNumber != 0 && teamleader.Shift != 0 && teamleader.PayRate != 0 && teamleader.MonthlyBonus != 0 
                && teamleader.ReqTrainHrs != 0 && !string.IsNullOrWhiteSpace(metTrainHrsTB.Text))
            {
                MessageBox.Show($"Name: {teamleader.FirstName} { teamleader.LastName} \nEmployee Number: {teamleader.EmpNumber} \n" +
                    $"Shift: {teamleader.Shift} \nHourly Pay Rate: ${teamleader.PayRate} \nMonthly Bonus: ${teamleader.MonthlyBonus} \nRequired Training Hours: {teamleader.ReqTrainHrs} \n" +
                    $"Attended Training Hours: {teamleader.MetTrainHrs}");
            }
                
            }

            private void button2_Click(object sender, EventArgs e)
            {
                //Close the form
                this.Close();
            }
        }
    }
