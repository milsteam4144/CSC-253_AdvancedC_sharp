﻿/**
* 11/14/2018
* CSC 253
* Mallory Milstead
* Displays the data from a table in a database. Uses query methods stored in the TableAdapter to sort the data and displays sorted tables.
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M5HW2_Milstead
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void employeeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.personnelDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'personnelDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.personnelDataSet.Employee);

        }

        private void ascendingButton_Click(object sender, EventArgs e)

        {
            //Calls the method
            this.employeeTableAdapter.FillByPay(this.personnelDataSet.Employee);
            //syntax is this.yourTableAdapter.MethodName(this.yourDataSet which is the database name.TableName)


        }

        private void descendingButton_Click(object sender, EventArgs e)
        {
            //Calls the method
            this.employeeTableAdapter.FillByPayDesc(this.personnelDataSet.Employee);
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
