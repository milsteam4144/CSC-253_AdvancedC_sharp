﻿/**
* 9/13/2018
* CSC 253
* Mallory Milstead
* This program reads values from a file and calculates/displays the sum of the values
*/



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace M2HW1_Milstead
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ReadSales(List<double> salesList)
        {
            foreach (double sale in salesList)
            {
                //Add the sale to the ListBox
                salesListBox.Items.Add(sale);
            }
        }

        private void GetSales(List<double> salesList)
        {
            //Open the file and get a StreamReader object
            StreamReader inputFile = File.OpenText("Sales.txt");


            //While it is not the end of the file, read the contents of the file
            while (!inputFile.EndOfStream)
            {
                //Add the sale to the list
                salesList.Add(double.Parse(inputFile.ReadLine()));
            }

            //Close the file
            inputFile.Close();
        }

        private double CalcTotal(List<double> salesList)
        {
            //Declare variable to hold the total
            double total = 0;

            //For each double in the list
            foreach (double sale in salesList)
            {
                //Add that amount to total
                total += sale;
            }

            //Return the total
            return total;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //On form load, create a list to hold sales
            List<double> salesList = new List<double>();
            //Call the method to add the values to the list
            GetSales(salesList);
            //Call the method to display the sales in the ListBox
            ReadSales(salesList);
        }

        private void calcTotalButton_Click(object sender, EventArgs e)
        {
            //Create a list to hold the sales numbers
            List<double> salesList = new List<double>();
            //Call the method to add the values to the list
            GetSales(salesList);
            //Display the total amount in a label by calling the method
            totalLabel.Text = CalcTotal(salesList).ToString("C");
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
