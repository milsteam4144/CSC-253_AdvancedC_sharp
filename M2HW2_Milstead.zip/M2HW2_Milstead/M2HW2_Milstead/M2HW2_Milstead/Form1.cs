﻿/**
* 9/12/2018
* CSC 253
* Mallory Milstead
* Reads input from two files, allows user to choose item (from first file) from ListBox. Counts the number of times the selcted item appears in a list of items read from the (second) file.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace M2HW2_Milstead
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                //Declare a variable to hold the team name
                string teamName;

                //Declare a StreamReader variable
                StreamReader teamFile;

                //Open the file and get a StreamReader object
                teamFile = File.OpenText("Teams.txt");

                //While it is not the end of the file, read the contents of the file
                while (!teamFile.EndOfStream)
                {
                    //Get a team name
                    teamName = teamFile.ReadLine();

                    //Add the team to the ListBox
                    teamListBox.Items.Add(teamName);

                }

                //Close the file
                teamFile.Close();
            }
            catch (Exception ex)
            {
                //Display an error message if the file cannot be found
                MessageBox.Show(ex.Message);
            }

    
        }


        private void displayButton_Click(object sender, EventArgs e)
        {
            //Get the selected item in a listbox and assign it to a variable
            string selectedTeam = teamListBox.GetItemText(teamListBox.SelectedItem);


            //Open the WorldSeriesWinners.txt file
            StreamReader winsFile = File.OpenText("WorldSeriesWinners.txt");

            //Declare a list to hold the wins
            List<string> winsList = new List<string>();

            //Read the scores into the list
            while (!winsFile.EndOfStream)
            {
                //Get a team name
                string wins = winsFile.ReadLine();

                winsList.Add(wins);
            }

            //Close the file
            winsFile.Close();


            //Declare variable to hold the number of wins
            int numOfwins = 0;

            //Loop through winsList
            foreach (string teams in winsList)
            {
                //If the string matches the selectedTeam, increment the counter variable
                if (teams == selectedTeam)
                {
                   numOfwins++;
                }

            }
            //Display the team name and the number of wins.
            displayLabel.Text = selectedTeam + " have won " + numOfwins.ToString() + " World Series!";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the progam.
            this.Close();
        }
    }
}
