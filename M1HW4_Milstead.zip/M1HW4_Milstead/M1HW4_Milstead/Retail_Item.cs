﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M1HW4_Milstead
{
    class Retail_Item
    {
        //Fields
        private string _description;
        private int _unitsOnHand;
        private decimal _price;


        //Constructor
        public Retail_Item(string Description, int UnitsOnHand, decimal Price)
        {
            _description = Description;
            _unitsOnHand = UnitsOnHand;
            _price = Price;
        }

        //get description property
        public string Description
        {
            get { return _description; }
        }

        //get unitsOnHand property
        public int UnitsOnHand
        {
            get { return _unitsOnHand; }
        }

        //get price property
        public decimal Price
        {
            get { return _price; }
        }
    }
}
