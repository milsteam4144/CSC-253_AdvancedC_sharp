﻿/**
* 9/7/2018
* CSC 253
* Mallory Milstead
* Create a class and an array of objects of the class. Use a foreach loop to iterate through the array and display the properties of the objects
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M1HW4_Milstead
{
    class Program
    {
        static void Main(string[] args)
        {
       
            //Create an array of three Retail_Item objects
            Retail_Item[] itemArray =
            {
                new Retail_Item("Jacket", 12, 59.95m),
                new Retail_Item("Jeans", 40, 34.95m),
                new Retail_Item("Shirt", 20, 24.95m),
        };

            //Write the item's properties to the console using a for loop to iterate through the array of objects
            foreach (Retail_Item item in itemArray) {
                Console.WriteLine("Description: " + item.Description + "\t" + "Units on Hand: " + item.UnitsOnHand + "\t" + "Price: " + item.Price.ToString("C"));
                }
            Console.ReadLine(); //To keep the console window open

        }
    }
}
