﻿/**
* 8/23/2018
* CSC 253
* Mallory Milstead
* Allow thew user to enter the number of books purchased and display points earned based on the number of books purchased
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M1HW1_Milstead
{
    public partial class bookClubForm : Form
    {
        public bookClubForm()
        {
            InitializeComponent();
        }

        //Click event to calculate the number of points earned.
        private void calcButton_Click(object sender, EventArgs e)
        {
            int booksPurchased; //To hold the number of books purchased
            int pointsEarned; //To hold the number of points

            //Try to parse the user input to an int
            if (int.TryParse(userInputTextBox.Text, out booksPurchased))
            {
                //Calculate the number of pointsEarned
                switch (booksPurchased)
                {
                    case 0:
                        pointsEarned = 0;
                        outputLabel.Text = ("You have earned " + (pointsEarned.ToString()) + " points!");
                        break;
                    case 1:
                        pointsEarned = 5;
                        outputLabel.Text = ("You have earned " + (pointsEarned.ToString()) + " points!");
                        break;
                    case 2:
                        pointsEarned = 15;
                        outputLabel.Text = ("You have earned " + (pointsEarned.ToString()) + " points!");
                        break;
                    case 3:
                        pointsEarned = 30;
                        outputLabel.Text = ("You have earned " + (pointsEarned.ToString()) + " points!");
                        break;
                    default:
                        if (booksPurchased >= 4)
                        {
                            pointsEarned = 60;
                            outputLabel.Text = ("You have earned " + (pointsEarned.ToString()) + " points!");
                        }
                        break;
                }

                        
                
            }


            else
            {
                MessageBox.Show("Enter a valid integer.");
            }


         }

        private void closeButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
 }
