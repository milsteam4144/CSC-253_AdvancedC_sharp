﻿/**
* 10/19/2018
* CSC 253
* Mallory Milstead
* Inputs a sentence and capitalizes the beginining of each new sentence
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW3_Milstead
{
    public partial class sentenceForm : Form
    {
        public sentenceForm()
        {
            InitializeComponent();
        }

        private void capitalizeButton_Click(object sender, EventArgs e)
        {
            //Get the string from the textbox and call the method on it.
            string raw_string = inputTextBox.Text;
            MessageBox.Show(cap_string(raw_string));
        }

        public string cap_string(string input)
        {
            //Create array to hold the characters that denote the end of a sentence.
            char [] end_of_sentence = new[] {'!', '.', '?'};
            //Create array of the words in the input string split by spaces
            string[] words = input.Split(' ');
            //Create a new string to hold the new sentence
            string new_string = "";
            //List to hold the int indexes of the words that contain an end_of_sentence character
            List<int> indexes = new List<int>();

            words[0] = words[0].First().ToString().ToUpper() + words[0].Substring(1); // Capitalize the first word in the sentence/array

            foreach (string word in words)//For each word in the sentence
            {


                    if (word.IndexOfAny(end_of_sentence) != -1) //if it contains an end_of_sentence character
                    {

                        new_string += word + " "; //Do not capitalize, just add to new sentence with a space
                        int last_word_position = Array.LastIndexOf(words, word);//Get the index of the word that contains the end_of_sentence character
                        indexes.Add(last_word_position);//Add the index to the list
                    }
              

                else //if it does not contain an end_of_sentence character
                {
                    if (!indexes.Contains(Array.LastIndexOf(words, word) - 1))//if the previous string does not contain an end_of_sentence character
                    {
                        new_string += word + " ";//Add the word to the new sentence as is
                    }
                    if (indexes.Contains(Array.LastIndexOf(words, word) - 1))//if the previous string does contain an end_of_sentence character
                    {

                        string cap_word = word.First().ToString().ToUpper() + word.Substring(1);//Get the first letter,convert to string, capitalize and add the rest of the word back
                        new_string += cap_word + " ";//Add the word to the new sentence
                    }

                }

            }

            return new_string;

        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }

    }

