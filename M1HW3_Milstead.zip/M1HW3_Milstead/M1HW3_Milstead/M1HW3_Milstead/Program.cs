﻿/**
* 9/5/2018
* CSC 253
* Mallory Milstead
* Allows the user to enter an objects mass and velocity to calculate the kinetic energy (using a method)
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M1HW3_Milstead
{
    class Program
    {
        static void Main(string[] args)
        {
            //Variables to hold user input
            double massInKG = 0, velocityInMeters = 0;

            //Variable to control loop
            string runAgain = "y";
            while (runAgain == "y")
            {
                Console.WriteLine("Enter the mass of the object in kilograms: ");
                if (double.TryParse(Console.ReadLine(), out massInKG)) //Parse input
                {

                    Console.WriteLine("Enter the velocity of the object in meters:"); //Parse input
                    if (double.TryParse(Console.ReadLine(), out velocityInMeters))
                    {
                        Console.WriteLine("The kinetic energy of the object is " + calcKineticEnergy(massInKG, velocityInMeters)); //Call function using input as arguments
                        Console.WriteLine("");
                    }
                    else
                    {
                        Console.WriteLine("Please enter a valid number for velocity in meters");
                    }
                }
                else
                {
                    Console.WriteLine("Please enter a valid number for mass in kilograms");
                }
                Console.WriteLine("Press \"y\" to run the program again...");
                runAgain = Console.ReadLine(); //Get user input to run program again
            }
        }

        //Function to calculate and return kinetic energy
        private static string calcKineticEnergy(double massInKG, double velocityInMeters)
        {
            double KE = .5 * massInKG * (velocityInMeters * velocityInMeters);
            string result = KE.ToString();//Parse double to string to display
            return result;
        }
    }
}


