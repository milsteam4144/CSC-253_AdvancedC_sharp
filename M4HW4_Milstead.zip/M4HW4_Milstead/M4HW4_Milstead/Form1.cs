﻿/**
* 11/9/2018
* CSC 253
* Mallory Milstead
* Creates a subclass from a parent class and displays properties of the object created from the subclass
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PersonClassLibrary;

namespace M4HW4_Milstead
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void createButton_Click(object sender, EventArgs e)
        {
            string displayMailList = "";

            //Create the object
            Customer customer = new Customer();
            GetCustomerData(customer);

           //String variable for bool
            if (customer.OnMailList == true)
            {
                 displayMailList = "Yes";
            }
            if (customer.OnMailList == false)
            {
                 displayMailList = "No";
            }

            if (customer.FirstName != null && customer.LastName != null && customer.Address != null && customer.Phone != null && customer.Cust_Num != 0 && customer.CheckedMailList != false)
            {

                MessageBox.Show($"Name: {customer.FirstName} {customer.LastName} \nAddress: {customer.Address} \n" +
                        $"Phone Number: {customer.Phone} \nCustomer Number: {customer.Cust_Num} \nOn Mailing List: {displayMailList}");
            }

        }

        public void GetCustomerData(Customer customer)
        {
            //Variables to hold input
            int custNum;

            if (firstNameTB.Text.Length != 0)
            {
                customer.FirstName = firstNameTB.Text;
            }

            else
            {
                MessageBox.Show("Must enter a first name.");
            }

            if (lastNameTB.Text.Length != 0)
            {
                customer.LastName = lastNameTB.Text;
            }

            else
            {
                MessageBox.Show("Must enter a last name.");
            }

            if (addressTB.Text.Length != 0)
            {
                customer.Address = addressTB.Text;
            }

            else
            {
                MessageBox.Show("Must enter an address.");
            }

            if (phoneTB.Text.Length == 14)
            {
                customer.Phone = phoneTB.Text;
            }

            else
            {
                MessageBox.Show("Must enter a valid phone number.");
            }

            if (int.TryParse(custNumTB.Text, out custNum))
            {
                customer.Cust_Num = custNum;
            }
            else
            {
                MessageBox.Show("Invalid Customer Number");

            }

            if (yesRadioButton.Checked == true)
            {
                customer.OnMailList = true;
                customer.CheckedMailList = true;
            }

            if (noRadioButton.Checked == true)
            {
                customer.OnMailList = false;
                customer.CheckedMailList = true;
            }
            if (!yesRadioButton.Checked && !noRadioButton.Checked)
            {
                customer.CheckedMailList = false;

                MessageBox.Show("Please select an option for mailing list.");
            }

        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}
