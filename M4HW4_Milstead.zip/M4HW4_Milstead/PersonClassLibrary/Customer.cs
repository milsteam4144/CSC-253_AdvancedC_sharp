﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonClassLibrary
{
    public class Customer : Person
    {
        public int Cust_Num { get; set; }

        public bool OnMailList { get; set; }

        public bool CheckedMailList { get; set; } //To determine if any checkbox has been checked

        public Customer()
        {
        }
    }
}
